/**
 * Car Navi Launcher - Main Application Logic
 */

// State Management
const state = {
  currentMapSource: 'osm', // 'osm', 'gmaps', 'vietmap', 'waze', 'custom'
  customMapUrl: '',
  speedLimit: 50,
  currentSpeed: 0,
  gpsMode: 'demo', // 'real' or 'demo'
  isDrivingDemo: true,
  currentLat: 10.7963,
  currentLng: 106.7214,
  currentBearing: 30,
  activeMediaTab: 'youtube', // 'youtube' or 'music'
  isMediaOpen: false,
  isMediaExpanded: false,
  isPlaying: false,
  currentTrackIndex: 0,
  tracks: [
    {
      id: 'demo-1',
      title: 'ZungZangZungZe',
      artist: 'Cheng, Han Sara',
      duration: 215,
      thumb: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&q=80',
      src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'
    },
    {
      id: 'demo-2',
      title: 'Lofi Chill Lái Xe Đêm',
      artist: 'Vietnam Chill Beats',
      duration: 184,
      thumb: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=150&q=80',
      src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'
    },
    {
      id: 'demo-3',
      title: 'Tình Ca Mùa Xuân',
      artist: 'Various Artists',
      duration: 242,
      thumb: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&q=80',
      src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'
    }
  ]
};

// DOM References
const dom = {
  clockDisplay: document.getElementById('clockDisplay'),
  locationStreet: document.getElementById('locationStreet'),
  locationSub: document.getElementById('locationSub'),
  locationCity: document.getElementById('locationCity'),
  weatherTemp: document.getElementById('weatherTemp'),
  weatherDesc: document.getElementById('weatherDesc'),
  
  // Dock
  btnApps: document.getElementById('btnApps'),
  btnNav: document.getElementById('btnNav'),
  btnMic: document.getElementById('btnMic'),
  btnTheme: document.getElementById('btnTheme'),
  btnSettings: document.getElementById('btnSettings'),
  btnYoutube: document.getElementById('btnYoutube'),
  btnMusic: document.getElementById('btnMusic'),

  // Mini Player
  miniThumb: document.getElementById('miniThumb'),
  miniTitle: document.getElementById('miniTitle'),
  miniArtist: document.getElementById('miniArtist'),
  miniEq: document.getElementById('miniEq'),
  miniPlayBtn: document.getElementById('miniPlayBtn'),
  miniPlayIcon: document.getElementById('miniPlayIcon'),
  miniPrevBtn: document.getElementById('miniPrevBtn'),
  miniNextBtn: document.getElementById('miniNextBtn'),
  miniProgressBar: document.getElementById('miniProgressBar'),
  miniProgressFill: document.getElementById('miniProgressFill'),

  // Split Media
  splitMediaPanel: document.getElementById('splitMediaPanel'),
  tabYoutubeBtn: document.getElementById('tabYoutubeBtn'),
  tabMusicBtn: document.getElementById('tabMusicBtn'),
  youtubeTabContent: document.getElementById('youtubeTabContent'),
  musicTabContent: document.getElementById('musicTabContent'),
  btnExpandMedia: document.getElementById('btnExpandMedia'),
  btnCloseMedia: document.getElementById('btnCloseMedia'),
  btnToggleSplit: document.getElementById('btnToggleSplit'),

  // YouTube
  ytIframe: document.getElementById('ytIframe'),
  ytSearchInput: document.getElementById('ytSearchInput'),
  ytSearchSubmit: document.getElementById('ytSearchSubmit'),
  btnOpenYtWeb: document.getElementById('btnOpenYtWeb'),

  // Local Music
  btnScanMusic: document.getElementById('btnScanMusic'),
  localFileInput: document.getElementById('localFileInput'),
  musicSearchInput: document.getElementById('musicSearchInput'),
  playlistContainer: document.getElementById('playlistContainer'),
  tabSongTitle: document.getElementById('tabSongTitle'),
  tabSongArtist: document.getElementById('tabSongArtist'),
  tabSongTime: document.getElementById('tabSongTime'),
  audioElement: document.getElementById('audioElement'),

  // Map & HUD
  leafletMap: document.getElementById('leafletMap'),
  externalMapFrame: document.getElementById('externalMapFrame'),
  speedLimitNumber: document.getElementById('speedLimitNumber'),
  hudSpeedLimit: document.getElementById('hudSpeedLimit'),
  currentSpeedVal: document.getElementById('currentSpeedVal'),
  sourceBadge: document.getElementById('sourceBadge'),
  currentSourceLabel: document.getElementById('currentSourceLabel'),
  sourceDropdown: document.getElementById('sourceDropdown'),
  btnRecenter: document.getElementById('btnRecenter'),
  btnZoomIn: document.getElementById('btnZoomIn'),
  btnZoomOut: document.getElementById('btnZoomOut'),

  // Modals
  settingsModal: document.getElementById('settingsModal'),
  btnCloseSettings: document.getElementById('btnCloseSettings'),
  btnSaveSettings: document.getElementById('btnSaveSettings'),
  settingMapSource: document.getElementById('settingMapSource'),
  customUrlGroup: document.getElementById('customUrlGroup'),
  settingCustomMapUrl: document.getElementById('settingCustomMapUrl'),
  settingGpsMode: document.getElementById('settingGpsMode'),

  appsModal: document.getElementById('appsModal'),
  btnCloseApps: document.getElementById('btnCloseApps')
};

// Global Map Instance
let mapInstance = null;
let carMarker = null;
let navigationRoute = null;

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
  initClock();
  initMap();
  initAudio();
  initEventListeners();
  loadSettings();
  renderPlaylist();

  // Try Android Bridge if running in APK
  if (window.CarNaviApp) {
    try {
      scanAndroidMusic();
    } catch (e) {
      console.log('Android Bridge init:', e);
    }
  }
});

/* ============================================================
   1. CLOCK & WEATHER
   ============================================================ */
function initClock() {
  function updateTime() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    dom.clockDisplay.textContent = `${hours}:${minutes}`;
  }
  updateTime();
  setInterval(updateTime, 1000);
}

/* ============================================================
   2. LEAFLET NAVIGATION MAP & HUD
   ============================================================ */
function initMap() {
  if (typeof L === 'undefined') {
    console.error('Leaflet not loaded, trying fallback');
    return;
  }

  // Location from screenshot: Tran Trong Kim, Binh Thanh, HCMC
  const startPos = [state.currentLat, state.currentLng];

  mapInstance = L.map('leafletMap', {
    center: startPos,
    zoom: 17,
    zoomControl: false,
    attributionControl: false
  });

  // CartoDB Voyager tiles (clean, stylish, 3D building outlines)
  L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
    maxZoom: 19,
    subdomains: 'abcd'
  }).addTo(mapInstance);

  // Custom Car 3D Navigation Chevron Marker
  const carIcon = L.divIcon({
    className: 'car-marker-container',
    html: `<div class="car-marker-arrow" id="carMarkerArrow" style="transform: rotate(${state.currentBearing}deg);"></div>`,
    iconSize: [48, 48],
    iconAnchor: [24, 24]
  });

  carMarker = L.marker(startPos, { icon: carIcon }).addTo(mapInstance);

  // Simulated Road Trajectory (Trần Trọng Kim -> Nguyễn Hữu Cảnh -> Cầu Sài Gòn)
  const routeCoords = [
    [10.7945, 106.7200],
    [10.7955, 106.7208],
    [10.7963, 106.7214],
    [10.7972, 106.7222],
    [10.7981, 106.7235],
    [10.7990, 106.7250]
  ];

  navigationRoute = L.polyline(routeCoords, {
    color: '#10B981',
    weight: 7,
    opacity: 0.85,
    lineJoin: 'round'
  }).addTo(mapInstance);

  // Start smooth car movement simulation if demo mode
  startDemoSimulation();
}

function startDemoSimulation() {
  let step = 0;
  const path = [
    { lat: 10.7963, lng: 106.7214, bearing: 30, speed: 38 },
    { lat: 10.7968, lng: 106.7218, bearing: 35, speed: 42 },
    { lat: 10.7972, lng: 106.7222, bearing: 40, speed: 48 },
    { lat: 10.7976, lng: 106.7227, bearing: 45, speed: 50 },
    { lat: 10.7972, lng: 106.7222, bearing: 220, speed: 35 },
    { lat: 10.7968, lng: 106.7218, bearing: 210, speed: 20 },
    { lat: 10.7963, lng: 106.7214, bearing: 30, speed: 0 }
  ];

  setInterval(() => {
    if (state.gpsMode !== 'demo') return;
    const target = path[step % path.length];
    step++;

    state.currentSpeed = target.speed;
    dom.currentSpeedVal.textContent = state.currentSpeed;

    // Check speed limit warning
    if (state.currentSpeed > state.speedLimit) {
      dom.currentSpeedVal.style.color = '#EF4444';
    } else {
      dom.currentSpeedVal.style.color = '#000000';
    }

    if (carMarker && mapInstance && state.currentMapSource === 'osm') {
      const newLatLng = [target.lat, target.lng];
      carMarker.setLatLng(newLatLng);
      const arrow = document.getElementById('carMarkerArrow');
      if (arrow) {
        arrow.style.transform = `rotate(${target.bearing}deg)`;
      }
    }
  }, 3000);
}

// Called from Kotlin Native Bridge when real GPS location updates
window.onGpsUpdate = function(data) {
  if (state.gpsMode !== 'real') return;
  state.currentLat = data.lat;
  state.currentLng = data.lng;
  state.currentSpeed = data.speed || 0;
  state.currentBearing = data.bearing || 0;

  dom.currentSpeedVal.textContent = state.currentSpeed;

  if (carMarker && mapInstance) {
    const latlng = [state.currentLat, state.currentLng];
    carMarker.setLatLng(latlng);
    mapInstance.panTo(latlng);
    const arrow = document.getElementById('carMarkerArrow');
    if (arrow) {
      arrow.style.transform = `rotate(${state.currentBearing}deg)`;
    }
  }
};

/* ============================================================
   3. MAP SOURCE SWITCHER
   ============================================================ */
function switchMapSource(sourceKey, customUrl = '') {
  state.currentMapSource = sourceKey;
  localStorage.setItem('carnavi_mapsource', sourceKey);

  // Update label
  const labels = {
    osm: 'OSM 3D Map',
    gmaps: 'Google Maps',
    vietmap: 'Vietmap Live',
    waze: 'Waze Traffic',
    custom: 'Custom Map'
  };
  dom.currentSourceLabel.textContent = labels[sourceKey] || 'Bản đồ';

  // Highlight active dropdown item
  document.querySelectorAll('.dropdown-item').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.source === sourceKey);
  });

  if (sourceKey === 'osm') {
    dom.leafletMap.style.display = 'block';
    dom.externalMapFrame.style.display = 'none';
    if (mapInstance) {
      setTimeout(() => mapInstance.invalidateSize(), 300);
    }
  } else {
    dom.leafletMap.style.display = 'none';
    dom.externalMapFrame.style.display = 'block';

    let targetUrl = '';
    const lat = state.currentLat;
    const lng = state.currentLng;

    if (sourceKey === 'gmaps') {
      targetUrl = `https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d15676.8!2d${lng}!3d${lat}!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1svi!2s`;
    } else if (sourceKey === 'vietmap') {
      targetUrl = `https://maps.vietmap.vn`;
    } else if (sourceKey === 'waze') {
      targetUrl = `https://embed.waze.com/iframe?zoom=16&lat=${lat}&lon=${lng}&ct=livemap`;
    } else if (sourceKey === 'custom') {
      targetUrl = customUrl || state.customMapUrl || 'https://www.openstreetmap.org';
    }

    dom.externalMapFrame.src = targetUrl;
  }

  dom.sourceDropdown.classList.remove('show');
}

/* ============================================================
   4. AUDIO & LOCAL MUSIC PLAYER
   ============================================================ */
function initAudio() {
  const audio = dom.audioElement;

  audio.addEventListener('timeupdate', () => {
    if (!audio.duration) return;
    const progress = (audio.currentTime / audio.duration) * 100;
    dom.miniProgressFill.style.width = `${progress}%`;

    const cur = formatTime(audio.currentTime);
    const total = formatTime(audio.duration);
    dom.tabSongTime.textContent = `${cur} / ${total}`;
  });

  audio.addEventListener('ended', () => {
    playNextTrack();
  });

  // Click seekbar to seek
  dom.miniProgressBar.addEventListener('click', (e) => {
    const rect = dom.miniProgressBar.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    if (audio.duration) {
      audio.currentTime = percent * audio.duration;
    }
  });

  // Set initial track
  loadTrack(0, false);
}

function loadTrack(index, autoPlay = true) {
  if (index < 0 || index >= state.tracks.length) return;
  state.currentTrackIndex = index;
  const track = state.tracks[index];

  dom.miniTitle.textContent = track.title;
  dom.miniArtist.textContent = track.artist;
  dom.tabSongTitle.textContent = track.title;
  dom.tabSongArtist.textContent = track.artist;

  if (track.thumb) {
    dom.miniThumb.src = track.thumb;
  }

  // Update playlist active item
  document.querySelectorAll('.song-row').forEach((row, idx) => {
    row.classList.toggle('active', idx === index);
  });

  if (window.CarNaviApp && track.isAndroidLocal && track.uri) {
    // Native Android local media playback
    if (autoPlay) {
      window.CarNaviApp.playAudio(track.uri);
      setPlayingState(true);
    }
  } else {
    dom.audioElement.src = track.src;
    if (autoPlay) {
      dom.audioElement.play().then(() => {
        setPlayingState(true);
      }).catch(err => {
        console.warn('Playback restricted until user clicks:', err);
      });
    }
  }
}

function togglePlay() {
  if (state.isPlaying) {
    if (window.CarNaviApp && state.tracks[state.currentTrackIndex]?.isAndroidLocal) {
      window.CarNaviApp.pauseAudio();
    } else {
      dom.audioElement.pause();
    }
    setPlayingState(false);
  } else {
    if (window.CarNaviApp && state.tracks[state.currentTrackIndex]?.isAndroidLocal) {
      window.CarNaviApp.resumeAudio();
    } else {
      dom.audioElement.play();
    }
    setPlayingState(true);
  }
}

function setPlayingState(isPlaying) {
  state.isPlaying = isPlaying;
  if (isPlaying) {
    dom.miniPlayIcon.className = 'fa-solid fa-pause';
    dom.miniEq.classList.add('active');
    document.querySelector('.vinyl-disc')?.classList.add('playing');
  } else {
    dom.miniPlayIcon.className = 'fa-solid fa-play';
    dom.miniEq.classList.remove('active');
    document.querySelector('.vinyl-disc')?.classList.remove('playing');
  }
}

function playNextTrack() {
  let next = state.currentTrackIndex + 1;
  if (next >= state.tracks.length) next = 0;
  loadTrack(next, true);
}

function playPrevTrack() {
  let prev = state.currentTrackIndex - 1;
  if (prev < 0) prev = state.tracks.length - 1;
  loadTrack(prev, true);
}

function renderPlaylist() {
  dom.playlistContainer.innerHTML = '';
  state.tracks.forEach((track, idx) => {
    const row = document.createElement('div');
    row.className = `song-row ${idx === state.currentTrackIndex ? 'active' : ''}`;
    row.innerHTML = `
      <div class="song-row-num">${idx + 1}</div>
      <div class="song-row-info">
        <div class="song-row-title">${escapeHtml(track.title)}</div>
        <div class="song-row-artist">${escapeHtml(track.artist)}</div>
      </div>
      <div class="song-row-duration">${formatTime(track.duration)}</div>
    `;
    row.addEventListener('click', () => {
      loadTrack(idx, true);
    });
    dom.playlistContainer.appendChild(row);
  });
}

function scanAndroidMusic() {
  if (!window.CarNaviApp) return;
  try {
    const jsonStr = window.CarNaviApp.scanLocalMusic();
    const list = JSON.parse(jsonStr);
    if (list && list.length > 0) {
      const formatted = list.map(item => ({
        id: item.id,
        title: item.title,
        artist: item.artist,
        duration: Math.round(item.duration / 1000),
        thumb: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&q=80',
        uri: item.uri,
        isAndroidLocal: true
      }));
      state.tracks = formatted;
      renderPlaylist();
      loadTrack(0, false);
      alert(`Đã tìm thấy ${list.length} bài hát trong thiết bị!`);
    } else {
      window.CarNaviApp.requestPermissions();
    }
  } catch (e) {
    console.error('Scan music failed:', e);
  }
}

// Handle manual file selection
dom.localFileInput.addEventListener('change', (e) => {
  const files = Array.from(e.target.files);
  if (!files.length) return;

  const imported = files.map((file, i) => ({
    id: `file-${Date.now()}-${i}`,
    title: file.name.replace(/\.[^/.]+$/, ""),
    artist: 'Thiết bị lưu trữ',
    duration: 180,
    thumb: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&q=80',
    src: URL.createObjectURL(file)
  }));

  state.tracks = imported.concat(state.tracks);
  renderPlaylist();
  loadTrack(0, true);
});

/* ============================================================
   5. SPLIT MEDIA PANEL (YOUTUBE & LOCAL MUSIC TABS)
   ============================================================ */
function openMediaPanel(tab = 'youtube') {
  state.isMediaOpen = true;
  state.activeMediaTab = tab;
  dom.splitMediaPanel.classList.add('open');

  switchMediaTab(tab);

  // Resize map
  setTimeout(() => {
    if (mapInstance) mapInstance.invalidateSize();
  }, 350);
}

function closeMediaPanel() {
  state.isMediaOpen = false;
  state.isMediaExpanded = false;
  dom.splitMediaPanel.classList.remove('open', 'expanded');
  dom.btnYoutube.classList.remove('active');
  dom.btnMusic.classList.remove('active');

  setTimeout(() => {
    if (mapInstance) mapInstance.invalidateSize();
  }, 350);
}

function switchMediaTab(tab) {
  state.activeMediaTab = tab;

  dom.tabYoutubeBtn.classList.toggle('active', tab === 'youtube');
  dom.tabMusicBtn.classList.toggle('active', tab === 'music');
  dom.youtubeTabContent.classList.toggle('active', tab === 'youtube');
  dom.musicTabContent.classList.toggle('active', tab === 'music');

  dom.btnYoutube.classList.toggle('active', tab === 'youtube');
  dom.btnMusic.classList.toggle('active', tab === 'music');
}

/* ============================================================
   6. YOUTUBE SEARCH & QUICK KEYWORDS
   ============================================================ */
function searchYouTube(query) {
  if (!query) return;
  // Embed search or curated playlist
  const embedUrl = `https://www.youtube.com/embed?listType=search&list=${encodeURIComponent(query)}&autoplay=1`;
  dom.ytIframe.src = embedUrl;
}

/* ============================================================
   7. EVENT LISTENERS
   ============================================================ */
function initEventListeners() {
  // Mini player controls
  dom.miniPlayBtn.addEventListener('click', togglePlay);
  dom.miniNextBtn.addEventListener('click', playNextTrack);
  dom.miniPrevBtn.addEventListener('click', playPrevTrack);

  // Dock items
  dom.btnNav.addEventListener('click', () => {
    closeMediaPanel();
  });

  dom.btnYoutube.addEventListener('click', () => {
    if (state.isMediaOpen && state.activeMediaTab === 'youtube') {
      closeMediaPanel();
    } else {
      openMediaPanel('youtube');
    }
  });

  dom.btnMusic.addEventListener('click', () => {
    if (state.isMediaOpen && state.activeMediaTab === 'music') {
      closeMediaPanel();
    } else {
      openMediaPanel('music');
    }
  });

  dom.btnToggleSplit.addEventListener('click', () => {
    if (state.isMediaOpen) {
      closeMediaPanel();
    } else {
      openMediaPanel(state.activeMediaTab);
    }
  });

  // Media tabs
  dom.tabYoutubeBtn.addEventListener('click', () => switchMediaTab('youtube'));
  dom.tabMusicBtn.addEventListener('click', () => switchMediaTab('music'));
  dom.btnCloseMedia.addEventListener('click', closeMediaPanel);

  dom.btnExpandMedia.addEventListener('click', () => {
    state.isMediaExpanded = !state.isMediaExpanded;
    dom.splitMediaPanel.classList.toggle('expanded', state.isMediaExpanded);
  });

  // YouTube controls
  dom.ytSearchSubmit.addEventListener('click', () => {
    searchYouTube(dom.ytSearchInput.value.trim());
  });
  dom.ytSearchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') searchYouTube(dom.ytSearchInput.value.trim());
  });
  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const q = chip.dataset.query;
      dom.ytSearchInput.value = q;
      searchYouTube(q);
    });
  });
  dom.btnOpenYtWeb.addEventListener('click', () => {
    dom.ytIframe.src = 'https://m.youtube.com';
  });

  // Local music scan
  dom.btnScanMusic.addEventListener('click', () => {
    if (window.CarNaviApp) {
      scanAndroidMusic();
    } else {
      dom.localFileInput.click();
    }
  });

  // Map HUD Speed limit click
  dom.hudSpeedLimit.addEventListener('click', () => {
    const limits = [40, 50, 60, 80, 90, 100, 120];
    const curIdx = limits.indexOf(state.speedLimit);
    const nextLimit = limits[(curIdx + 1) % limits.length];
    setSpeedLimit(nextLimit);
  });

  // Map Source Dropdown Toggle
  dom.sourceBadge.addEventListener('click', (e) => {
    e.stopPropagation();
    dom.sourceDropdown.classList.toggle('show');
  });

  document.addEventListener('click', (e) => {
    if (!dom.sourceBadge.contains(e.target) && !dom.sourceDropdown.contains(e.target)) {
      dom.sourceDropdown.classList.remove('show');
    }
  });

  document.querySelectorAll('.dropdown-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const src = btn.dataset.source;
      if (src === 'custom') {
        openSettingsModal();
      } else {
        switchMapSource(src);
      }
    });
  });

  // Map zoom controls
  dom.btnZoomIn.addEventListener('click', () => {
    if (mapInstance && state.currentMapSource === 'osm') mapInstance.zoomIn();
  });
  dom.btnZoomOut.addEventListener('click', () => {
    if (mapInstance && state.currentMapSource === 'osm') mapInstance.zoomOut();
  });
  dom.btnRecenter.addEventListener('click', () => {
    if (mapInstance && state.currentMapSource === 'osm') {
      mapInstance.setView([state.currentLat, state.currentLng], 17);
    }
  });

  // Theme toggle
  dom.btnTheme.addEventListener('click', () => {
    document.body.classList.toggle('theme-dark');
    const isDark = document.body.classList.contains('theme-dark');
    localStorage.setItem('carnavi_theme', isDark ? 'dark' : 'light');
  });

  // Voice Assistant
  dom.btnMic.addEventListener('click', () => {
    if (window.CarNaviApp) {
      window.CarNaviApp.launchVoiceAssistant();
    } else {
      alert('Đang kích hoạt nhận diện giọng nói tiếng Việt...');
    }
  });

  // Settings Modal
  dom.btnSettings.addEventListener('click', openSettingsModal);
  dom.btnCloseSettings.addEventListener('click', closeSettingsModal);
  dom.btnSaveSettings.addEventListener('click', saveSettings);

  dom.settingMapSource.addEventListener('change', () => {
    dom.customUrlGroup.style.display = dom.settingMapSource.value === 'custom' ? 'flex' : 'none';
  });

  document.querySelectorAll('.limit-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.limit-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
    });
  });

  // Apps Modal
  dom.btnApps.addEventListener('click', () => dom.appsModal.classList.add('show'));
  dom.btnCloseApps.addEventListener('click', () => dom.appsModal.classList.remove('show'));
  
  // App shortcuts
  document.getElementById('appLaunchGmaps')?.addEventListener('click', () => {
    dom.appsModal.classList.remove('show');
    switchMapSource('gmaps');
  });
  document.getElementById('appLaunchYoutube')?.addEventListener('click', () => {
    dom.appsModal.classList.remove('show');
    openMediaPanel('youtube');
  });
  document.getElementById('appLaunchMusic')?.addEventListener('click', () => {
    dom.appsModal.classList.remove('show');
    openMediaPanel('music');
  });
}

/* ============================================================
   8. SETTINGS MANAGEMENT
   ============================================================ */
function setSpeedLimit(limit) {
  state.speedLimit = limit;
  dom.speedLimitNumber.textContent = limit;
  localStorage.setItem('carnavi_speedlimit', limit);
}

function openSettingsModal() {
  dom.settingMapSource.value = state.currentMapSource;
  dom.settingCustomMapUrl.value = state.customMapUrl;
  dom.customUrlGroup.style.display = state.currentMapSource === 'custom' ? 'flex' : 'none';
  dom.settingGpsMode.value = state.gpsMode;

  document.querySelectorAll('.limit-chip').forEach(chip => {
    chip.classList.toggle('active', parseInt(chip.dataset.limit) === state.speedLimit);
  });

  dom.settingsModal.classList.add('show');
}

function closeSettingsModal() {
  dom.settingsModal.classList.remove('show');
}

function saveSettings() {
  const source = dom.settingMapSource.value;
  const customUrl = dom.settingCustomMapUrl.value.trim();
  const activeLimitChip = document.querySelector('.limit-chip.active');
  const limit = activeLimitChip ? parseInt(activeLimitChip.dataset.limit) : 50;

  state.customMapUrl = customUrl;
  localStorage.setItem('carnavi_customurl', customUrl);

  state.gpsMode = dom.settingGpsMode.value;
  setSpeedLimit(limit);
  switchMapSource(source, customUrl);

  closeSettingsModal();
}

function loadSettings() {
  const savedSource = localStorage.getItem('carnavi_mapsource') || 'osm';
  const savedUrl = localStorage.getItem('carnavi_customurl') || '';
  const savedLimit = parseInt(localStorage.getItem('carnavi_speedlimit')) || 50;
  const savedTheme = localStorage.getItem('carnavi_theme') || 'light';

  state.customMapUrl = savedUrl;
  setSpeedLimit(savedLimit);
  if (savedTheme === 'dark') document.body.classList.add('theme-dark');
  switchMapSource(savedSource, savedUrl);
}

/* ============================================================
   9. UTILITIES
   ============================================================ */
function formatTime(seconds) {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
